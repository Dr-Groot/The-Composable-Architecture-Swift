import SwiftUI
import ComposableArchitecture

@main
struct TestTCA_4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView(store: Store(initialState: .init(dataDetail: "Search ... "), reducer: appReducer, environment: AppEnvironment()))
        }
    }
}
