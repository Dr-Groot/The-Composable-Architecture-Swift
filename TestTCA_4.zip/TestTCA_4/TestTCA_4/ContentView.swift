import SwiftUI
import ComposableArchitecture

//MARK: - STATE
struct AppState : Equatable {
    var dataDetail: String
}

//MARK: - ACTION
enum AppAction : Equatable {
    case show, empty
}

//MARK: - ENVIRONMENT
struct AppEnvironment {
    var showdata = "Hello theree"
    var emptyData = "GONE"
}

//MARK: - REDUCER
let appReducer = Reducer<AppState, AppAction, AppEnvironment> { state, action, environment in
    switch action {
    case .show:
        state.dataDetail = environment.showdata
        return .none
    case .empty:
        state.dataDetail = environment.emptyData
        return .none
    }
}

//MARK: - VIEW
struct ContentView: View {
    let store: Store<AppState, AppAction>
    var body: some View {
        WithViewStore(store) { viewStore in
            VStack {
                Spacer()
                
                Text("\(viewStore.dataDetail)")
                    .font(.largeTitle)

                Spacer()
                
                Button(
                    action: { viewStore.send(.show) },
                    label: {
                        Text("Search")
                            .font(.title)
                            .frame(width: 200, height: 44, alignment: .center)
                    }
                )
                    .buttonStyle(.borderedProminent)
                
                Button(
                    action: { viewStore.send(.empty) },
                    label: {
                        Text("Clear")
                            .font(.title)
                            .frame(width: 200, height: 44, alignment: .center)
                    }
                )
                    .buttonStyle(.borderedProminent)
                
                .padding()
            }
        }
    }
}

//MARK: - STORE
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(store: Store(initialState: .init(dataDetail: "Search ... "), reducer: appReducer, environment: AppEnvironment()))
    }
}
