import SwiftUI
import ComposableArchitecture

//MARK: - STATE
struct AppState: Equatable {
    var count: Int
    var numberFactAlert: String?
}

//MARK: - ACTION
enum AppAction: Equatable {
  case factAlertDismissed
  case decrementButtonTapped
  case incrementButtonTapped
  case numberFactButtonTapped
  case numberFactResponse(TaskResult<String>)
}

//MARK: - ENVIRONMENT
struct AppEnvironment {
  var numberFact: (Int) async throws -> String
}

//MARK: - REDUCER
let appReducer = Reducer<AppState, AppAction, AppEnvironment> { state, action, environment in
  switch action {
  case .factAlertDismissed:
    state.numberFactAlert = nil
    return .none

  case .decrementButtonTapped:
    state.count -= 1
    return .none

  case .incrementButtonTapped:
    state.count += 1
    return .none

  case .numberFactButtonTapped:
    return .task {
        await .numberFactResponse(TaskResult { try await environment.numberFact(state.count) })
    }

  case let .numberFactResponse(.success(fact)):
    state.numberFactAlert = fact
    return .none

  case .numberFactResponse(.failure):
    state.numberFactAlert = "Could not load a number fact :("
    return .none
  }
}

//MARK: - VIEW
struct ContentView: View {
  let store: Store<AppState, AppAction>

  var body: some View {
    WithViewStore(self.store) { viewStore in
      VStack {
        HStack {
          Button("−") { viewStore.send(.decrementButtonTapped) }
          Text("\(viewStore.count)")
          Button("+") { viewStore.send(.incrementButtonTapped) }
        }

        Button("Number fact") { viewStore.send(.numberFactButtonTapped) }
      }
      .alert(
        item: viewStore.binding(
          get: { $0.numberFactAlert.map(FactAlert.init(title:)) },
          send: .factAlertDismissed
        ),
        content: { Alert(title: Text($0.title)) }
      )
    }
  }
}

struct FactAlert: Identifiable {
  var title: String
  var id: String { self.title }
}


//MARK: - STORE
@main
struct TestTCA_5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView(store: Store(
                initialState: AppState(count: 0),
                reducer: appReducer,
                environment: AppEnvironment(
                  numberFact: { number in
                    let (data, _) = try await URLSession.shared.data(from: .init(string: "http://numbersapi.com/\(number)")!)
                      return String(decoding: data, as: UTF8.self)
                  }
                )
              ))
        }
    }
}
