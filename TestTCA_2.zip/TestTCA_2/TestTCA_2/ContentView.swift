import SwiftUI
import ComposableArchitecture

// MARK: - STATE
// A type that describes the data your feature needs to perform its logic and render its UI.
// We use struct for state bcz its hold the whole bunch of independent pieces of data.

struct AppState {

}

// MARK: - ACTION
// A type that represents all of the actions that can happen in your feature, such as user actions, notifications, event sources and more.
// We use enum action becuase it represent one of many different types of action that user can perform on UI such as tapping the button or entering text in text Field. Sometime actions can be struct.

enum AppAction{

}

// MARK: - ENVIRONMENT
// A type that holds any dependencies the feature needs, such as API clients, analytics clients, etc.
// It holds all the dependencies that the feature needs to its job.It is struct bcz dependencies are independent from each other.

struct AppEnivronment{

}

// MARK: - REDUCER
// It is responsible for business logic that runs the application.In this closure we will put all the logics of the applicaiton.
// A function that describes how to evolve the current state of the app to the next state given an action. The reducer is also responsible for returning any effects that should be run, such as API requests, which can be done by returning an Effect value.
// USING SWITCH: switching the action and we will consider each case in the AppAction enum and for each case we run the business logic related to that action. Business logic means very specific.
let appReducer = Reducer<AppState, AppAction, AppEnivronment> { state, action, environment in
    switch action {
    }
}

//MARK: - VIEW
struct ContentView: View {
    let store: Store<AppState, AppAction>
    var body: some View {
        WithViewStore(store) { ViewStore in

        }
    }
}


// MARK: - STORE-
// The runtime that actually drives your feature. You send all user actions to the store so that the store can run the reducer and effects, and you can observe state changes in the store so that you can update UI.
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(
            store: Store(
                initialState: AppState(),
                reducer: appReducer,
                environment: AppEnivronment()
            )
        )
    }
}
