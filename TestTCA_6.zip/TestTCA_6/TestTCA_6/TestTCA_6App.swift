import SwiftUI
import ComposableArchitecture

//MARK: - STATE
struct appState: Equatable {
    var result: WeatherModel
}

//MARK: - ACTION
enum appAction : Equatable {
    case show
    case showResponse(TaskResult<WeatherModel>)
}

//MARK: - ENVIRONMENT
struct appEnvironment {
    var weatherResult: ([Double]) async throws -> WeatherModel
}

//MARK: - REDUCER
let appReducer = Reducer<appState, appAction, appEnvironment> { state, action, envirnonment in
    switch action {
    case .show:
        return .task {
            await .showResponse(TaskResult {try await envirnonment.weatherResult([13.3524, 74.7868])})
        }
    case let.showResponse(.success(data)):
        state.result = data
        return .none
    case .showResponse(.failure):
        return .none
    }
}

//MARK: - VIEW
struct ContentView: View {
    let store: Store<appState, appAction>

    var body: some View {
        WithViewStore(self.store) { viewStore in
            VStack {
                Group{
                    Text("Latitude: \(viewStore.result.coord.lat)")
                    Text("Longitude: \(viewStore.result.coord.lon)")
                    Text("Base: \(viewStore.result.base)")
                    Text("Temperature: \(viewStore.result.main.temp)")
                    Text("Max Temperature: \(viewStore.result.main.tempMax)")
                    Text("Min Temperature: \(viewStore.result.main.tempMin)")
                    Text("Feels Like: \(viewStore.result.main.feelsLike)")
                    Text("Pressure: \(viewStore.result.main.pressure)")
                    Text("Humidity: \(viewStore.result.main.humidity)")
                    Text("Visibility: \(viewStore.result.visibility)")
                }
                Group{
                    Text("Wind Speed: \(viewStore.result.wind.speed)")
                    Text("Wind Deg: \(viewStore.result.wind.deg)")
                    Text("Clouds: \(viewStore.result.clouds.all)")
                    Text("Dt: \(viewStore.result.dt)")
                    Text("Sys Type: \(viewStore.result.sys.type)")
                    Text("Sys Id: \(viewStore.result.sys.id)")
                    Text("Country: \(viewStore.result.sys.country)")
                    Text("Sunrise: \(viewStore.result.sys.sunrise)")
                    Text("Sunset: \(viewStore.result.sys.sunset)")
                    Text("Timezone: \(viewStore.result.timezone)")
                }
                Group{
                    Text("Name: \(viewStore.result.name)")
                    Text("Cod: \(viewStore.result.cod)")
                }
                
                    Button(
                        action: { viewStore.send(.show) },
                        label: {
                            Text("Get Weather")
                                .font(.title)
                                .frame(width: 200, height: 44, alignment: .center)
                        }
                    )
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}


//MARK: - STORE
@main
struct TestTCA_6App: App {
    var body: some Scene {
        WindowGroup<ContentView> {
            ContentView(store: Store(
                initialState: appState(result: WeatherModel.mock),
                reducer: appReducer,
                environment: appEnvironment(
                  weatherResult: { value in
                    let (data, _) = try await URLSession.shared.data(from: .init(string: "https://api.openweathermap.org/data/2.5/weather?lat=\(value[0])&lon=\(value[1])&appid=25131c8017007d77ce859e890bd03436")!)
                      let decoder = JSONDecoder()
                      let loadData = try! decoder.decode(WeatherModel.self, from: data)
                      return loadData
                  }
                )
              ))
        }
    }
}
