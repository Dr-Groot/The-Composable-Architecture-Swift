//
//  TestTCA_3AppTest.swift
//  TestTCA_3
//
//  Created by Amam Pratap Singh on 17/08/22.
//
//
//import ComposableArchitecture
//import XCTest
//@testable import TestTCA_3
//
//class TestTCA_3AppTest: XCTestCase {
//    func testExample() throws {
//        let store = TestStore(initialState: AppState(count: 0), reducer: appReducer, environment: ())
//
//        store.send(.increment) { state in
//            state.count = 1
//        }
//        store.send(.increment) { $0.count = 2 }
//        store.send(.decrement) { $0.count = 1 }
//    }
//}
