import SwiftUI
import ComposableArchitecture

//MARK: - STATE
struct AppState : Equatable {
    var count: Int
}

//MARK: - ACTION
enum AppAction : Equatable {
    case increment, decrement
}

//MARK: - REDUCER
let appReducer = Reducer<AppState, AppAction, Void> { state, action, _ in
    switch action {
    case .increment:
        state.count += 1
        return .none
    // Return in aciton switch is just returning the effect after any action if we want
    // EX: return Effect(value: .decrement)

    case .decrement:
        state.count -= 1
        return .none
    }
}

//MARK: - VIEW
struct ContentView: View {
    let store: Store<AppState, AppAction>

    var body: some View {
        WithViewStore(store) { viewStore in
            VStack {
                Spacer()

                Text("\(viewStore.count)")
                    .font(.largeTitle)

                Spacer()

                HStack {
                    Button(
                        action: { viewStore.send(.decrement) },
                        label: {
                            Image(systemName: "minus")
                                .font(.title)
                                .frame(width: 44, height: 44, alignment: .center)
                        }
                    )
                        .buttonStyle(.borderedProminent)

                    Spacer()

                    Button(
                        action: { viewStore.send(.increment) },
                        label: {
                            Image(systemName: "plus")
                                .font(.title)
                                .frame(width: 44, height: 44, alignment: .center)
                        }
                    )
                        .buttonStyle(.borderedProminent)
                }
                .padding()
            }
        }
    }
}


//MARK: - STORE
@main
struct TestTCA_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView(store: Store(initialState: .init(count: 0), reducer: appReducer, environment: ()))
        }
    }
}
